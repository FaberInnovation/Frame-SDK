﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using System.Net;
using System.Text;
using System.IO;
using Java.Net;
using System.Threading;

namespace FrameApp
{
    [Activity(Label = "Frame", MainLauncher = true, Icon = "@drawable/icon", ScreenOrientation = Android.Content.PM.ScreenOrientation.Portrait)]
    public class MainActivity : Activity
    {
        const float AlphaLow = 0.5F;

        EditText editIP;
        ImageView imageSplash;
        ImageButton buttonTwitter;
        ImageButton buttonFacebook;
        ImageButton buttonBbc;
        ImageButton buttonFinance;
        ImageButton buttonImage1;
        ImageButton buttonImage2;
        ImageButton buttonImage3;
        ImageButton buttonSlider;
        ImageButton buttonMirror1;
        ImageButton buttonCommand;
        ImageButton buttonSensor;
        ImageButton buttonGoHome;

        ImageButton buttonPower0;
        ImageButton buttonPower1;
        ImageButton buttonPower2;
        ImageButton buttonPower3;
        ImageButton buttonLight0;
        ImageButton buttonLight1;
        ImageButton buttonLight2;
        ImageButton buttonLight3;

        Button buttonImagePrev;
        Button buttonImageNext;
        Button buttonBrowserUp;
        Button buttonBrowserDown;
        Button buttonSensorPrev;
        Button buttonSensorNext;

        GridLayout layoutHome;
        GridLayout layoutCommand;
        GridLayout layoutImage;
        LinearLayout layoutBrowser;
        LinearLayout layoutSensor;
        Button buttonHome;

        TextView textSensorName;
        TextView textSensorUM;
        TextView textSensorValue;

        string[] sensorIDs;
        int sensorIndex = 0;
        String currentIP = "";
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            Window.RequestFeature(WindowFeatures.NoTitle);
            Window.SetSoftInputMode(SoftInput.StateAlwaysHidden);

            loadHome();
            sendRequest(getUrlRequest("show-home", ""));

            imageSplash.Visibility = ViewStates.Visible;
        }

        public void onPause()
        {
            base.OnPause();  // Always call the superclass method first

            // Release the Camera because we don't need it when paused
            // and other activities might need to use it.

        }

        private void loadHome()
        {
            SetContentView(Resource.Layout.Main);

            editIP = FindViewById<EditText>(Resource.Id.editIP);
            if (currentIP == "") currentIP = GetIPAddress();
            editIP.Text = currentIP;
            
            layoutHome = FindViewById<GridLayout>(Resource.Id.layoutHome);
            buttonHome = FindViewById<Button>(Resource.Id.buttonHome);
            layoutCommand = FindViewById<GridLayout>(Resource.Id.layoutCommand);
            layoutImage = FindViewById<GridLayout>(Resource.Id.layoutImage);
            layoutBrowser= FindViewById<LinearLayout>(Resource.Id.layoutBrowser);
            layoutSensor = FindViewById<LinearLayout>(Resource.Id.layoutSensor);

            layoutHome.Visibility = ViewStates.Visible;
            buttonHome.Visibility = ViewStates.Gone;
            layoutCommand.Visibility = ViewStates.Gone;
            layoutImage.Visibility = ViewStates.Gone;
            layoutBrowser.Visibility = ViewStates.Gone;
            layoutSensor.Visibility = ViewStates.Gone;
            FindViewById<LinearLayout>(Resource.Id.linearLayout2).ScrollTo(0, 0);

            imageSplash = FindViewById<ImageView>(Resource.Id.imageSplash);
            imageSplash.Visibility = ViewStates.Gone;
            imageSplash.Click += delegate { imageSplash.Visibility = ViewStates.Gone; };

            buttonTwitter = FindViewById<ImageButton>(Resource.Id.buttonTwitter);
            buttonFacebook = FindViewById<ImageButton>(Resource.Id.buttonFacebook);
            buttonBbc = FindViewById<ImageButton>(Resource.Id.buttonBbc);
            buttonFinance = FindViewById<ImageButton>(Resource.Id.buttonFinance);
            buttonImage1 = FindViewById<ImageButton>(Resource.Id.buttonImage1);
            buttonImage2 = FindViewById<ImageButton>(Resource.Id.buttonImage2);
            buttonImage3 = FindViewById<ImageButton>(Resource.Id.buttonImage3);
            buttonSlider = FindViewById<ImageButton>(Resource.Id.buttonSlider);
            buttonMirror1 = FindViewById<ImageButton>(Resource.Id.buttonMirror1);
            buttonCommand = FindViewById<ImageButton>(Resource.Id.buttonCommand);
            buttonSensor = FindViewById<ImageButton>(Resource.Id.buttonSensor);
            buttonGoHome = FindViewById<ImageButton>(Resource.Id.buttonGoHome);

            buttonTwitter.Click += delegate { sendRequest(getUrlRequest("show-twitter", "")); loadBrowser(); };
            buttonFacebook.Click += delegate { sendRequest(getUrlRequest("show-facebook", "")); loadBrowser(); };
            buttonBbc.Click += delegate { sendRequest(getUrlRequest("show-bbc", "")); loadBrowser(); };
            buttonFinance.Click += delegate { sendRequest(getUrlRequest("show-finance", "")); loadBrowser(); };
            //buttonImage1.Click += delegate { loadGallery("1", 4); };
            //buttonImage2.Click += delegate { loadGallery("2", 2); };
            //buttonImage3.Click += delegate { loadGallery("3", 2); };
            buttonImage1.Click += delegate { sendRequest(getUrlRequest("show-browser", "http://www.franke.com/dct/en/home/meat-recipes/starter/gruyere-cream-puffs.html")); loadBrowser(); };
            buttonImage2.Click += delegate { sendRequest(getUrlRequest("show-browser", "http://www.franke.com/dct/en/home/meat-recipes/main-course/stuffed-guinea-fowl.html")); loadBrowser(); };
            buttonImage3.Click += delegate { sendRequest(getUrlRequest("show-browser", "http://www.franke.com/dct/en/home/meat-recipes/dessert/chocolate-cake-with-chili-pepper.html")); loadBrowser(); };
            buttonSlider.Click += delegate { sendRequest(getUrlRequest("show-slider", "A")); showMirror(); };
            buttonMirror1.Click += delegate { sendRequest(getUrlRequest("set-mirror", "1")); showMirror(); };
            buttonCommand.Click += delegate { loadCommand(); };
            buttonSensor.Click += delegate { loadSensor(0); };
            buttonGoHome.Click += delegate { sendRequest(getUrlRequest("show-home", "")); showMirror(); };

            buttonHome.Click += delegate { sendRequest(getUrlRequest("show-home", "")); loadHome(); };
            showMirror();

            buttonPower0 = FindViewById<ImageButton>(Resource.Id.buttonPower0);
            buttonPower1 = FindViewById<ImageButton>(Resource.Id.buttonPower1);
            buttonPower2 = FindViewById<ImageButton>(Resource.Id.buttonPower2);
            buttonPower3 = FindViewById<ImageButton>(Resource.Id.buttonPower3);
            buttonLight0 = FindViewById<ImageButton>(Resource.Id.buttonLight0);
            buttonLight1 = FindViewById<ImageButton>(Resource.Id.buttonLight1);
            buttonLight2 = FindViewById<ImageButton>(Resource.Id.buttonLight2);
            buttonLight3 = FindViewById<ImageButton>(Resource.Id.buttonLight3);
            buttonPower0.Click += delegate { sendRequest(getUrlRequest("set-power", "0")); showPower(); };
            buttonPower1.Click += delegate { sendRequest(getUrlRequest("set-power", "1")); showPower(); };
            buttonPower2.Click += delegate { sendRequest(getUrlRequest("set-power", "2")); showPower(); };
            buttonPower3.Click += delegate { sendRequest(getUrlRequest("set-power", "3")); showPower(); };
            buttonLight0.Click += delegate { sendRequest(getUrlRequest("set-light", "0")); showLight(); };
            buttonLight1.Click += delegate { sendRequest(getUrlRequest("set-light", "1")); showLight(); };
            buttonLight2.Click += delegate { sendRequest(getUrlRequest("set-light", "2")); showLight(); };
            buttonLight3.Click += delegate { sendRequest(getUrlRequest("set-light", "3")); showLight(); };

            buttonImagePrev = FindViewById<Button>(Resource.Id.buttonImagePrev);
            buttonImageNext = FindViewById<Button>(Resource.Id.buttonImageNext);
            buttonBrowserUp = FindViewById<Button>(Resource.Id.buttonBrowserUp);
            buttonBrowserDown = FindViewById<Button>(Resource.Id.buttonBrowserDown);
            buttonSensorPrev = FindViewById<Button>(Resource.Id.buttonSensorPrev);
            buttonSensorNext = FindViewById<Button>(Resource.Id.buttonSensorNext);
            buttonImagePrev.Click += delegate { sendRequest(getUrlRequest("image-prev", "")); };
            buttonImageNext.Click += delegate { sendRequest(getUrlRequest("image-next", "")); };
            buttonBrowserUp.Click += delegate { sendRequest(getUrlRequest("browser-up", "")); };
            buttonBrowserDown.Click += delegate { sendRequest(getUrlRequest("browser-down", "")); };

            textSensorName = FindViewById<TextView>(Resource.Id.textSensorName);
            textSensorUM = FindViewById<TextView>(Resource.Id.textSensorUM);
            textSensorValue = FindViewById<TextView>(Resource.Id.textSensorValue);
            buttonSensorPrev.Click += delegate { loadSensor(-1); };
            buttonSensorNext.Click += delegate { loadSensor(+1); };
            textSensorValue.Click += delegate { loadSensor(0); };
            GetSensorIDs();

        }

        private void showMirror()
        {
            String Mirror = sendRequest(getUrlRequest("get-mirror", ""));
            buttonMirror1.Alpha = (Mirror == "0" ? 1 : AlphaLow);
        }

        private void loadCommand()
        {
            layoutHome.Visibility = ViewStates.Gone;
            buttonHome.Visibility = ViewStates.Visible;
            layoutCommand.Visibility = ViewStates.Visible;
            FindViewById<LinearLayout>(Resource.Id.linearLayout2).ScrollTo(0, 0);

            sendRequest(getUrlRequest("show-command", ""));
            showPower();
            showLight();
        }

        private void showPower()
        {
            String Power = sendRequest(getUrlRequest("get-power", ""));
            buttonPower0.Alpha = (Power == "0" ? 1 : AlphaLow);
            buttonPower1.Alpha = (Power == "1" ? 1 : AlphaLow);
            buttonPower2.Alpha = (Power == "2" ? 1 : AlphaLow);
            buttonPower3.Alpha = (Power == "3" ? 1 : AlphaLow);
        }
        private void showLight()
        {
            String Light = sendRequest(getUrlRequest("get-light", ""));
            buttonLight0.Alpha = (Light == "0" ? 1 : AlphaLow);
            buttonLight1.Alpha = (Light == "1" ? 1 : AlphaLow);
            buttonLight2.Alpha = (Light == "2" ? 1 : AlphaLow);
            buttonLight3.Alpha = (Light == "3" ? 1 : AlphaLow);
        }

        ImageView lastImg;
        private void loadGallery(String galleryName, int count)
        {
            /*
            var layout = new ScrollView(this);

            var aButton = new Button(this);
            aButton.Text = "Back";

            LinearLayout view = new LinearLayout(this);
            view.Orientation = Orientation.Vertical;
            layout.AddView(view);

            aButton.Click += delegate { loadHome(); };
            view.AddView(aButton);

            String Image = sendRequest(getUrlRequest("get-image", ""));
            for (int i = 1; i <= count; i++)
            {
                ImageView img = new ImageView(this);
                img.Tag = galleryName + "\\" + i.ToString();
                img.SetImageResource(Resources.GetIdentifier("image_" + galleryName + "_" + i.ToString(), "drawable", PackageName));
                img.LayoutParameters = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MatchParent, ViewGroup.LayoutParams.WrapContent);
                img.SetScaleType(ImageView.ScaleType.CenterInside);
                img.SetPadding(10, 0, 10, 10);
                img.SetAdjustViewBounds(true);
                //img.LayoutParameters.Height = 300;
                img.Click += delegate { sendRequest(getUrlRequest("show-image", (String)img.Tag)); if (lastImg != null) lastImg.Alpha = AlphaLow; lastImg = img; img.Alpha = 1; };
                img.Alpha = (Image == (String)img.Tag ? 1 : AlphaLow);
                if (Image == (String)img.Tag) lastImg = img;
                view.AddView(img);
            }
            

            SetContentView(layout);
            */

            layoutHome.Visibility = ViewStates.Gone;
            buttonHome.Visibility = ViewStates.Visible;
            layoutImage.Visibility = ViewStates.Visible;
            FindViewById<LinearLayout>(Resource.Id.linearLayout2).ScrollTo(0, 0);

            sendRequest(getUrlRequest("show-image", galleryName + "\\1"));
        }

        private void loadBrowser()
        {
            layoutHome.Visibility = ViewStates.Gone;
            buttonHome.Visibility = ViewStates.Visible;
            layoutBrowser.Visibility = ViewStates.Visible;
            FindViewById<LinearLayout>(Resource.Id.linearLayout2).ScrollTo(0, 0);
        }

        private string GetIPAddress()
        {
            Android.Net.Wifi.WifiManager manager = (Android.Net.Wifi.WifiManager)GetSystemService(Service.WifiService);
            int ip = manager.ConnectionInfo.IpAddress;
            String ips = Android.Text.Format.Formatter.FormatIpAddress(ip);
            string[] parts = ips.Split('.');
            parts[3] = "10";
            return parts[0] + "." + parts[1] + "." + parts[2] + "." + parts[3];
        }
        private string getUrlRequest(String action, String value)
        {
            currentIP = editIP.Text;
            return "http://" + currentIP + "/FrameMonitor/?action=" + action + "&value=" + value;
        }

        // Gets weather data from the passed URL.  
        private string sendRequest(string url)
        {
            try
            {
                // Create an HTTP web request using the URL:
                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(new Uri(url));
                request.ContentType = "application/x-www-form-urlencoded";
                request.Method = "GET";

                // Send the request to the server and wait for the response:
                using (WebResponse response = request.GetResponse())
                {
                    var encoding = ASCIIEncoding.UTF8;

                    // Get a stream representation of the HTTP web response:
                    using (Stream stream = response.GetResponseStream())
                    {
                        string ret = "";
                        using (var reader = new StreamReader(stream, encoding))
                            ret = reader.ReadToEnd();

                        //  Console.Out.WriteLine("Response: {0}", ret);

                        // Return the JSON document:
                        return ret;
                    }
                }
            }

            catch (WebException e)
            {
                Toast.MakeText(this, "Non connesso\n\r" + e.Message, ToastLength.Short).Show();
               // ShowAlert("Errore sync", e.Message);
                return null;
            }
        }

        private void ShowAlert(String title, String message)
        {
            AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(this);
            alertDialog2.SetTitle(title);
            alertDialog2.SetMessage(message);
            alertDialog2.SetPositiveButton("OK", delegate { alertDialog2.Dispose(); });
            alertDialog2.Show();
        }
        private void GetSensorIDs()
        {
            String ret = sendRequest(getUrlRequest("get-sensors", ""));
            if (ret != null) sensorIDs = ret.Split('|');
            else Toast.MakeText(this, "Sensori non disponibili\n\r", ToastLength.Short).Show();
        }
        private void loadSensor(int delta)
        {
            if (sensorIDs == null) {
                GetSensorIDs();
            }
            if (sensorIDs == null)
            {
                Toast.MakeText(this, "Sensori non disponibili.", ToastLength.Short).Show();
                return;
            }

            sensorIndex += delta;
            if (sensorIndex == -1) sensorIndex = sensorIDs.Length - 1;
            if (sensorIndex == sensorIDs.Length) sensorIndex = 0;

            layoutHome.Visibility = ViewStates.Gone;
            buttonHome.Visibility = ViewStates.Visible;
            layoutSensor.Visibility = ViewStates.Visible;

            String ret = sendRequest(getUrlRequest("get-sensor-info", sensorIDs[sensorIndex]));
            string[] parts = ret.Split('|');
            if (parts.Length == 4) {
                textSensorName.Text = parts[0];
                textSensorUM.Text = parts[1];
                textSensorValue.Text = parts[2];
            }
        }

    }

}